Assumptions:

- data directory contains many files and directories
- you are only interested in the games contaiend and pdf's tutorials in this directory
- each game is stored in a directory that contains the word "game"
- each pdf file contains the word "python"

Project Steps/Requirements:

- Find all game directories from /data
- Find all python pdf;s files from /data
- Create a new directories according to csv file attached int he zip folder.
- Copy all games into the /games directory
- Copy all python pdf files into /tutorials directory
- Create a .json file with the information about the games ???

NOTE:

- The directories from each studend should be empty.
