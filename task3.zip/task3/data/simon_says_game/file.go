package main

import "fmt"

func main() {
	fmt.Println("Simon says")
}
